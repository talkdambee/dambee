
import React from 'react';

function App() {
  return (
    <div>
      <h1>담비(Dambee)에 오신 걸 환영합니다!</h1>
      <p>이건 React로 만든 기본 구조입니다.</p>
    </div>
  );
}

export default App;
